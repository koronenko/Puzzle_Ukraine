﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_games_catalog
{
    public partial class First_Control1 : UserControl
    {
        public First_Control1()
        {
            InitializeComponent();
        }
    }
}
